var refz = escape(document.referrer)+"";

if (navigator.cookieEnabled) { cSupport = navigator.cookieEnabled; } else cSupport = "undefined"; var URLloc = escape(document.location)+"";
function machiner() { if (navigator.cpuClass) { switch (navigator.cpuClass) { case "x86" : theCpu = "x86 [Intel processor]"; break; case "68K" : theCpu = "68K [Motorola processor]"; break; case "Alpha" : theCpu = "Alpha [Digital processor]"; break; case "PPC" : theCpu = "PPC [Motorola processor]"; break; case "Other" : theCpu = "Other"; break; }; } else { theCpu = "Undefined"; }; return theCpu; }; var cpuz = machiner();
var usd = screen.width + "x" + screen.height ; var usc = screen.colorDepth + "Bit";
dpass="&cSupport="+cSupport+"&cpuz="+cpuz+"&usd="+usd+"&usc="+usc+"&refz="+refz+"&URLloc="+URLloc;

st="<img src='"; mi="http://www.yourdomain.com/yourpathto/UFDust.cgi?"; en="' alt='' border='0'>";

document.write(st+mi+dpass+en);